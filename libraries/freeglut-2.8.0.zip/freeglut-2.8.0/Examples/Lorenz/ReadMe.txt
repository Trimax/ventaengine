
---------------
Building Lorenz
---------------

Creating a Shared Version
-------------------------

gcc -Wall lorenz.c -lfreeglut32 -lglu32 -lopengl32 -lwinmm -lgdi32 -mwindows -o lorenz.exe

Creating a Static Version
-------------------------

gcc -Wall lorenz.c -DFREEGLUT_STATIC -lfreeglut32_static -lglu32 -lopengl32 -lwinmm -lgdi32 -mwindows -o lorenz.exe

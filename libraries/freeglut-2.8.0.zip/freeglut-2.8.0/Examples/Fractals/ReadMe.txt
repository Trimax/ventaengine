
-----------------
Building Fractals
-----------------

Creating a Shared Version
-------------------------

gcc -Wall fractals.c -lfreeglut32 -lglu32 -lopengl32 -lwinmm -lgdi32 -mwindows -o fractals.exe

Creating a Static Version
-------------------------

gcc -Wall fractals.c -DFREEGLUT_STATIC -lfreeglut32_static -lglu32 -lopengl32 -lwinmm -lgdi32 -mwindows -o fractals.exe


-----------------
Building FreeGLUT
-----------------

The following Instructions are based on some found at the following blog: http://bit.ly/wkUHeY

Creating a Shared Library
-------------------------

gcc -O2 -c -DFREEGLUT_EXPORTS -DWINVER=0x0500 *.c -I../include

gcc -shared -o freeglut32.dll *.o -Wl,--enable-stdcall-fixup,--out-implib,libfreeglut32.a -lopengl32 -lglu32 -lgdi32 -lwinmm

Creating a Static Library
-------------------------

gcc -O2 -c -DFREEGLUT_STATIC -DWINVER=0x0500 *.c -I../include

ar rcs libfreeglut32_static.a *.o

Placement of DLL
----------------

C:\MinGW\bin

Placement of Shared & Static Libraries
--------------------------------------

C:\MinGW\lib
